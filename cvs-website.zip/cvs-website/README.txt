CVS AUTOMOTIVE — Free Landing Page
==================================

HOW TO GET YOUR FREE URL (under 2 minutes)

Option 1 — Netlify Drop (easiest, no account needed)
----------------------------------------------------
1. Go to: https://app.netlify.com/drop
2. Drag this entire "cvs-website" folder onto the page
3. Wait a few seconds
4. You will receive a free URL like:
   https://something-random-123.netlify.app

Option 2 — GitHub Pages (permanent & free)
------------------------------------------
1. Create a free GitHub account if you don’t have one
2. Create a new repository named "cvs-automotive"
3. Upload the index.html file
4. Go to Settings → Pages → Deploy from main branch
5. Your site will be at:
   https://yourusername.github.io/cvs-automotive

Option 3 — Vercel
-----------------
1. Go to https://vercel.com
2. Import the folder or connect a GitHub repo
3. Deploy — you get a free .vercel.app URL

After you have the free URL, you can later point 
www.cvsautomotive.com to it once you register the domain.

File included:
- index.html   (the complete one-page website)
